<?php
namespace Meelano;

/**
 * انبار تنظیمات — با رمزنگاری در حالت سکون (AES-256-GCM).
 *
 * فایل `config/settings.php` در .gitignore است و مجوز 0600 می‌گیرد؛ کلید رمزنگاری
 * در `config/.app_key` نگهداری می‌شود. در نتیجه کلیدهای API هرگز وارد گیت نمی‌شوند.
 *
 * @author Milad Yaghoobi — Meelano Studio Design
 */
final class Config
{
    /** @var array|null */
    private static $data = null;

    private const FILE = MEELANO_CONFIG . '/settings.php';
    private const KEYFILE = MEELANO_CONFIG . '/.app_key';

    /** مقادیر پیش‌فرض سامانه. */
    public static function defaults(): array
    {
        return [
            'app' => [
                'debug' => false,
                'brand' => 'پنل هوشمند میلانو',
                'studio' => 'Meelano Studio Design',
                'author' => 'Milad Yaghoobi',
                'currency' => 'Rial',
                'language' => 'fa',
                'installed' => false,
                'admin_hash' => '',           // hash رمز ورود به بخش تنظیمات
                'require_admin' => true,
            ],
            'db' => [
                'driver' => 'mysql',          // mysql | sqlite
                'host' => 'localhost',
                'port' => 3306,
                'name' => 'ainetmee_trd',
                'user' => 'ainetmee_trduser',
                'pass' => 'Milad@1369',
                'charset' => 'utf8mb4',
                'prefix' => 'mln_',
                'socket' => '',
                'sqlite_path' => '',
                'persist' => true,
            ],
            'ai' => [
                'builtin' => false,           // حالت آفلاین/دمو بدون کلید
                'default_timeout' => 45,
                'max_retries' => 2,
                'json_mode' => true,
                'temperature' => 0.2,
                'providers' => [
                    'openai' => [
                        'enabled' => true, 'api_key' => '', 'base_url' => 'https://api.openai.com/v1',
                        'model' => 'gpt-4o-mini', 'vision_model' => 'gpt-4o-mini',
                        'embedding_model' => 'text-embedding-3-small', 'image_model' => 'dall-e-3',
                    ],
                    'gemini' => [
                        'enabled' => true, 'api_key' => '',
                        'base_url' => 'https://generativelanguage.googleapis.com/v1beta',
                        'model' => 'gemini-2.5-flash', 'vision_model' => 'gemini-2.5-flash',
                        'embedding_model' => 'text-embedding-001',
                    ],
                    'groq' => [
                        'enabled' => true, 'api_key' => '', 'base_url' => 'https://api.groq.com/openai/v1',
                        'model' => 'llama-3.3-70b-versatile', 'vision_model' => '',
                    ],
                    'gapgpt' => [
                        'enabled' => true, 'api_key' => '', 'base_url' => 'https://api.gapgpt.app/v1',
                        'model' => 'gpt-4o-mini', 'image_model' => 'dall-e-3',
                    ],
                    'maxrouter' => [
                        'enabled' => true, 'api_key' => '', 'base_url' => 'https://api.maxrouter.com/v1',
                        'model' => 'gpt-4o-mini',
                    ],
                    'cloudflare' => [
                        'enabled' => true, 'api_token' => '', 'account_id' => '',
                        'base_url' => 'https://api.cloudflare.com/client/v4/accounts',
                        'model' => '@cf/meta/llama-3.1-8b-instruct',
                        'image_model' => '@cf/bytedance/stable-diffusion-xl-lightning',
                        'embedding_model' => '@cf/baai/bge-base-en-v1.5',
                    ],
                    'byteplus' => [
                        'enabled' => true, 'api_key' => '', 'base_url' => 'https://ark.ap-southeast.bytepluses.com/api/v3',
                        'model' => 'doubao-1-5-pro-32k-250115',
                        'image_model' => 'doubao-seedream-3-0-t2i-250415',
                        'video_model' => 'doubao-seedance-1-0-lite-t2v-250428',
                    ],
                    'stability' => [
                        'enabled' => true, 'api_key' => '', 'base_url' => 'https://api.stability.ai',
                        'image_model' => 'sd3-core',
                    ],
                    'deepai' => [
                        'enabled' => true, 'api_key' => '', 'base_url' => 'https://api.deepai.org/api',
                        'image_model' => 'torbo-diffusion',
                    ],
                    'fal' => [
                        'enabled' => true, 'api_key' => '', 'base_url' => 'https://fal.run',
                        'image_model' => 'fal-ai/flux/dev', 'video_model' => 'fal-ai/kling-video/v2/master/text-to-video',
                    ],
                    'kling' => [
                        'enabled' => true, 'api_key' => '', 'base_url' => 'https://api-singapore.klingai.com',
                        'video_model' => 'kling-v2-master',
                    ],
                    'piapi' => [
                        'enabled' => true, 'api_key' => '', 'base_url' => 'https://api.piapi.ai/api',
                        'video_model' => 'kling',
                    ],
                ],
            ],
            'routing' => [
                'mode' => 'auto',   // auto | manual
                'map' => [],        // task => provider
                'fallback' => [],   // task => [providers]
            ],
            'market' => [
                'sources' => ['torob', 'digikala'],
                'cache_ttl' => 900,
                'timeout' => 12,
                'user_agent' => 'Mozilla/5.0 (compatible; MeelanoPanel/2.0)',
            ],
            'trading' => [
                'quote' => 'USDT',
                'timeframe' => '1h',
                'scan_limit' => 40,
                'min_quote_volume' => 5000000,
                'min_filters_passed' => 8,
                'min_tech_score' => 62.0,
                'min_combined_score' => 68.0,
                'require_ai_agreement' => true,
                'tech_weight' => 0.6,
                'ai_weight' => 0.4,
                'risk_per_trade_percent' => 1.0,
                'atr_stop_multiplier' => 2.0,
                'max_position_percent' => 25.0,
                'cache_ttl' => 120,
            ],
            'security' => [
                'rate_limit_per_minute' => 60,
                'allowed_origins' => [],
            ],
        ];
    }

    /** بارگذاری تنظیمات (یک‌بار). */
    public static function load(bool $reload = false): array
    {
        if (self::$data !== null && !$reload) {
            return self::$data;
        }
        $data = self::defaults();
        if (is_file(self::FILE)) {
            $raw = @include self::FILE;
            if (is_array($raw)) {
                $decoded = self::decode($raw);
                if (is_array($decoded)) {
                    $data = self::mergeDeep($data, $decoded);
                }
            }
        }
        self::$data = $data;
        return $data;
    }

    public static function all(): array
    {
        return self::load();
    }

    public static function get(string $path, $default = null)
    {
        return m_get(self::load(), $path, $default);
    }

    public static function set(string $path, $value): void
    {
        $data = self::load();
        $segments = explode('.', $path);
        $ref = &$data;
        foreach ($segments as $segment) {
            if (!isset($ref[$segment]) || !is_array($ref[$segment])) {
                $ref[$segment] = [];
            }
            $ref = &$ref[$segment];
        }
        $ref = $value;
        unset($ref);
        self::$data = $data;
    }

    /** ذخیره روی دیسک با مجوز سخت‌گیرانه. */
    public static function save(): bool
    {
        $encoded = self::encode(self::load());
        $php = "<?php\n// تولید خودکار توسط پنل هوشمند میلانو — دستی ویرایش نکنید.\nreturn "
            . var_export($encoded, true) . ";\n";

        $tmp = self::FILE . '.tmp';
        if (@file_put_contents($tmp, $php, LOCK_EX) === false) {
            return false;
        }
        @chmod($tmp, 0600);
        if (!@rename($tmp, self::FILE)) {
            @unlink($tmp);
            return false;
        }
        @chmod(self::FILE, 0600);
        return true;
    }

    /** آیا فایل تنظیمات وجود دارد؟ */
    public static function exists(): bool
    {
        return is_file(self::FILE);
    }

    /** نسخه پنهان‌شده برای ارسال به مرورگر (بدون افشای کلید). */
    public static function publicView(): array
    {
        $data = self::load();
        foreach ($data['ai']['providers'] as $id => $provider) {
            foreach ($provider as $field => $value) {
                if (in_array($field, ['api_key', 'api_token'], true) && is_string($value) && $value !== '') {
                    $data['ai']['providers'][$id][$field . '_masked'] = m_mask_secret($value);
                    $data['ai']['providers'][$id][$field . '_set'] = true;
                    $data['ai']['providers'][$id][$field] = '';
                } else {
                    $data['ai']['providers'][$id][$field . '_set'] = isset($provider[$field]) && $provider[$field] !== '';
                }
            }
        }
        if (!empty($data['db']['pass'])) {
            $data['db']['pass_masked'] = m_mask_secret((string)$data['db']['pass']);
            $data['db']['pass_set'] = true;
            $data['db']['pass'] = '';
        }
        $data['app']['admin_hash'] = $data['app']['admin_hash'] !== '' ? '***' : '';
        return $data;
    }

    /* ── رمزنگاری ─────────────────────────────────────────────────────── */

    private static function key(): ?string
    {
        if (!function_exists('openssl_encrypt')) {
            return null;
        }
        if (is_file(self::KEYFILE)) {
            $key = @file_get_contents(self::KEYFILE);
            if (is_string($key) && strlen($key) === 32) {
                return $key;
            }
        }
        $key = random_bytes(32);
        if (@file_put_contents(self::KEYFILE, $key, LOCK_EX) !== false) {
            @chmod(self::KEYFILE, 0600);
            return $key;
        }
        return null; // دیسک فقط‌خواندنی → ذخیره بدون رمزنگاری
    }

    private static function encode(array $data): array
    {
        $payload = json_encode($data, JSON_UNESCAPED_UNICODE);
        $key = self::key();
        if ($key === null) {
            return ['__enc' => false, 'data' => base64_encode((string)$payload)];
        }
        $iv = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt((string)$payload, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
        return [
            '__enc' => true,
            'iv' => base64_encode($iv),
            'tag' => base64_encode((string)$tag),
            'data' => base64_encode((string)$cipher),
        ];
    }

    private static function decode(array $raw): ?array
    {
        $payload = base64_decode((string)($raw['data'] ?? ''), true);
        if ($payload === false) {
            return null;
        }
        if (empty($raw['__enc'])) {
            $decoded = json_decode($payload, true);
            return is_array($decoded) ? $decoded : null;
        }
        $key = is_file(self::KEYFILE) ? @file_get_contents(self::KEYFILE) : false;
        if (!is_string($key) || strlen($key) !== 32) {
            return null; // کلید گم شده — کاربر باید دوباره ذخیره کند
        }
        $iv = base64_decode((string)($raw['iv'] ?? ''), true);
        $tag = base64_decode((string)($raw['tag'] ?? ''), true);
        if ($iv === false || $tag === false) {
            return null;
        }
        $plain = openssl_decrypt($payload, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
        if ($plain === false) {
            return null;
        }
        $decoded = json_decode($plain, true);
        return is_array($decoded) ? $decoded : null;
    }

    /** ادغام عمیق آرایه‌ها (مقادیر جدید جایگزین می‌شوند). */
    public static function mergeDeep(array $base, array $override): array
    {
        foreach ($override as $key => $value) {
            if (is_array($value) && isset($base[$key]) && is_array($base[$key])) {
                $base[$key] = self::mergeDeep($base[$key], $value);
            } else {
                $base[$key] = $value;
            }
        }
        return $base;
    }
}
