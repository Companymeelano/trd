<?php
declare(strict_types=1);

define('TRD_APP', true);

require __DIR__ . '/config.php';
require __DIR__ . '/market.php';
require __DIR__ . '/indicators.php';
require __DIR__ . '/decision.php';

/**
 * ارسال خطای JSON و توقف امن اجرای اسکریپت
 */
function backtest_error(
    string $message,
    int $status = 500,
    ?Throwable $exception = null
): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');

    $response = [
        'status'  => 'error',
        'message' => $message,
    ];

    /*
     * نمایش جزئیات خطا فقط در حالت Debug
     */
    $debug = false;

    if (class_exists('Config') && method_exists('Config', 'appDebug')) {
        try {
            $debug = (bool) Config::appDebug();
        } catch (Throwable $ignored) {
            $debug = false;
        }
    }

    if (
        defined('APP_DEBUG') &&
        filter_var(APP_DEBUG, FILTER_VALIDATE_BOOLEAN)
    ) {
        $debug = true;
    }

    if ($debug && $exception !== null) {
        $response['detail'] = $exception->getMessage();
        $response['file']   = basename($exception->getFile());
        $response['line']   = $exception->getLine();
    }

    echo json_encode(
        $response,
        JSON_UNESCAPED_UNICODE |
        JSON_UNESCAPED_SLASHES |
        JSON_INVALID_UTF8_SUBSTITUTE
    );

    exit;
}

try {
    /*
     * احراز هویت
     */
    require_auth();

    /*
     * دریافت Body به‌صورت JSON
     */
    $body = get_json_body();

    if (!is_array($body)) {
        backtest_error(
            'بدنه درخواست JSON معتبر نیست.',
            400
        );
    }

    /*
     * ورودی‌ها
     */
    $symbol = strtoupper(
        trim((string)($body['symbol'] ?? 'BTCUSDT'))
    );

    $timeframe = trim(
        (string)($body['timeframe'] ?? '1h')
    );

    $capital = (
        isset($body['capital']) &&
        is_numeric($body['capital'])
    )
        ? (float)$body['capital']
        : 1000.0;

    $riskPct = (
        isset($body['risk_pct']) &&
        is_numeric($body['risk_pct'])
    )
        ? (float)$body['risk_pct']
        : 0.01;

    $news = trim(
        (string)($body['news_status'] ?? 'normal')
    );

    /*
     * بررسی تنظیمات پایه
     */
    if (
        !defined('DEFAULT_SYMBOLS') ||
        !is_array(DEFAULT_SYMBOLS)
    ) {
        backtest_error(
            'DEFAULT_SYMBOLS در تنظیمات تعریف نشده است.',
            500
        );
    }

    if (
        !defined('DEFAULT_TIMEFRAMES') ||
        !is_array(DEFAULT_TIMEFRAMES)
    ) {
        backtest_error(
            'DEFAULT_TIMEFRAMES در تنظیمات تعریف نشده است.',
            500
        );
    }

    /*
     * اعتبارسنجی نماد
     */
    if (!in_array($symbol, DEFAULT_SYMBOLS, true)) {
        backtest_error(
            'Invalid symbol. Allowed: ' .
            implode(',', DEFAULT_SYMBOLS),
            400
        );
    }

    /*
     * اعتبارسنجی تایم‌فریم
     */
    if (!in_array($timeframe, DEFAULT_TIMEFRAMES, true)) {
        backtest_error(
            'Invalid timeframe. Allowed: ' .
            implode(',', DEFAULT_TIMEFRAMES),
            400
        );
    }

    /*
     * اعتبارسنجی سرمایه
     */
    if (
        !is_finite($capital) ||
        $capital < 10 ||
        $capital > 100000000
    ) {
        backtest_error(
            'Capital must be between 10 and 100,000,000.',
            400
        );
    }

    /*
     * risk_pct به‌صورت اعشاری دریافت می‌شود.
     *
     * مثال:
     * 1 درصد = 0.01
     * 0.5 درصد = 0.005
     */
    if (
        !is_finite($riskPct) ||
        $riskPct <= 0 ||
        $riskPct > 0.01
    ) {
        backtest_error(
            'risk_pct must be decimal fraction between 0 and 0.01.',
            400
        );
    }

    /*
     * اعتبارسنجی وضعیت اخبار
     */
    if (!in_array($news, ['normal', 'cpi'], true)) {
        backtest_error(
            'Invalid news_status.',
            400
        );
    }

    /*
     * دریافت داده‌های بازار
     */
    try {
        $cache = get_klines_cached(
            $symbol,
            $timeframe,
            800
        );
    } catch (Throwable $e) {
        backtest_error(
            'Market data error: ' . $e->getMessage(),
            502,
            $e
        );
    }

    $klines = is_array($cache)
        ? ($cache['data'] ?? [])
        : [];

    if (!is_array($klines)) {
        backtest_error(
            'Market data format is invalid.',
            502
        );
    }

    /*
     * حداقل داده مورد نیاز اندیکاتورها
     */
    if (count($klines) < 120) {
        backtest_error(
            'Not enough historical data for backtest.',
            400
        );
    }

    /*
     * متغیرهای موتور بک‌تست
     */
    $equity = $capital;
    $peak = $capital;
    $maxDrawdown = 0.0;

    $trades = [];
    $position = null;

    /*
     * اجرای بک‌تست
     */
    for (
        $i = 60;
        $i < count($klines) - 1;
        $i++
    ) {
        $currentCandle = $klines[$i] ?? [];

        if (!is_array($currentCandle)) {
            continue;
        }

        if (
            !isset(
                $currentCandle['open'],
                $currentCandle['high'],
                $currentCandle['low'],
                $currentCandle['close']
            )
        ) {
            continue;
        }

        $high = (float)$currentCandle['high'];
        $low  = (float)$currentCandle['low'];

        /*
         * مدیریت پوزیشن باز
         */
        if ($position !== null) {
            $exitPrice = null;
            $exitType = null;

            /*
             * در صورت برخورد هم‌زمان SL و TP،
             * SL اولویت دارد؛ محافظه‌کارانه‌تر است.
             */
            if ($low <= $position['sl']) {
                $exitPrice = $position['sl'];
                $exitType = 'SL';
            } elseif ($high >= $position['tp2']) {
                $exitPrice = $position['tp2'];
                $exitType = 'TP2';
            } elseif ($high >= $position['tp1']) {
                $exitPrice = $position['tp1'];
                $exitType = 'TP1';
            }

            if (
                $exitPrice !== null &&
                $exitType !== null
            ) {
                $pnl = (
                    $exitPrice - $position['entry']
                ) * $position['units'];

                $equity += $pnl;

                $trades[] = [
                    'entry' => $position['entry'],
                    'exit'  => $exitPrice,
                    'type'  => $exitType,
                    'pnl'   => $pnl,
                ];

                $position = null;
            }
        }

        /*
         * بررسی سیگنال جدید
         */
        if ($position === null) {
            $slice = array_slice(
                $klines,
                0,
                $i + 1
            );

            try {
                $signal = evaluate_signal(
                    $slice,
                    $news
                );
            } catch (Throwable $e) {
                backtest_error(
                    'Signal evaluation failed: ' .
                    $e->getMessage(),
                    500,
                    $e
                );
            }

            if (
                is_array($signal) &&
                ($signal['decision'] ?? null) === 'EXECUTE'
            ) {
                $nextCandle = $klines[$i + 1] ?? null;

                if (
                    !is_array($nextCandle) ||
                    !isset($nextCandle['open'])
                ) {
                    continue;
                }

                $entry = (float)$nextCandle['open'];

                /*
                 * آماده‌سازی آرایه‌های عددی برای ATR
                 */
                $highs = [];
                $lows = [];
                $closes = [];

                foreach ($slice as $candle) {
                    if (!is_array($candle)) {
                        continue;
                    }

                    if (
                        !isset(
                            $candle['high'],
                            $candle['low'],
                            $candle['close']
                        )
                    ) {
                        continue;
                    }

                    $highs[]  = (float)$candle['high'];
                    $lows[]   = (float)$candle['low'];
                    $closes[] = (float)$candle['close'];
                }

                if (
                    count($highs) < 20 ||
                    count($lows) < 20 ||
                    count($closes) < 20
                ) {
                    continue;
                }

                try {
                    $atrVal = atr(
                        $highs,
                        $lows,
                        $closes,
                        14
                    );
                } catch (Throwable $e) {
                    backtest_error(
                        'ATR calculation failed: ' .
                        $e->getMessage(),
                        500,
                        $e
                    );
                }

                if (
                    $atrVal === null ||
                    !is_numeric($atrVal) ||
                    (float)$atrVal <= 0
                ) {
                    continue;
                }

                $atrVal = (float)$atrVal;

                $stopLoss = $entry - (1.5 * $atrVal);
                $tp1 = $entry + (2.0 * $atrVal);
                $tp2 = $entry + (4.0 * $atrVal);

                $distance = $entry - $stopLoss;

                if (
                    !is_finite($distance) ||
                    $distance <= 0 ||
                    $equity <= 0
                ) {
                    continue;
                }

                $riskAmount = $equity * $riskPct;
                $units = $riskAmount / $distance;

                if (
                    !is_finite($units) ||
                    $units <= 0
                ) {
                    continue;
                }

                $positionUsd = $units * $entry;

                $position = [
                    'entry'        => $entry,
                    'sl'           => $stopLoss,
                    'tp1'          => $tp1,
                    'tp2'          => $tp2,
                    'units'        => $units,
                    'position_usd' => $positionUsd,
                ];
            }
        }

        /*
         * محاسبه Drawdown
         */
        if ($equity > $peak) {
            $peak = $equity;
        }

        $drawdown = $peak > 0
            ? (($peak - $equity) / $peak) * 100
            : 0.0;

        if ($drawdown > $maxDrawdown) {
            $maxDrawdown = $drawdown;
        }
    }

    /*
     * بستن پوزیشن باز در پایان داده‌ها
     */
    if ($position !== null) {
        $lastCandle = $klines[count($klines) - 1] ?? [];

        $lastClose = is_array($lastCandle) &&
            isset($lastCandle['close'])
            ? (float)$lastCandle['close']
            : (float)$position['entry'];

        $pnl = (
            $lastClose - $position['entry']
        ) * $position['units'];

        $equity += $pnl;

        $trades[] = [
            'entry' => $position['entry'],
            'exit'  => $lastClose,
            'type'  => 'CLOSE',
            'pnl'   => $pnl,
        ];

        if ($equity > $peak) {
            $peak = $equity;
        }

        $drawdown = $peak > 0
            ? (($peak - $equity) / $peak) * 100
            : 0.0;

        if ($drawdown > $maxDrawdown) {
            $maxDrawdown = $drawdown;
        }
    }

    /*
     * محاسبه آمار نهایی
     */
    $total = count($trades);
    $wins = 0;
    $grossProfit = 0.0;
    $grossLoss = 0.0;

    foreach ($trades as $trade) {
        $pnl = (float)($trade['pnl'] ?? 0);

        if ($pnl > 0) {
            $wins++;
            $grossProfit += $pnl;
        } elseif ($pnl < 0) {
            $grossLoss += abs($pnl);
        }
    }

    $winRate = $total > 0
        ? ($wins / $total) * 100
        : 0.0;

    $profitFactor = $grossLoss > 0
        ? $grossProfit / $grossLoss
        : ($grossProfit > 0 ? 999.0 : 0.0);

    $profitPct = $capital > 0
        ? (($equity - $capital) / $capital) * 100
        : 0.0;

    /*
     * پاسخ موفق
     */
    json_response([
        'status' => 'success',
        'result' => [
            'total_trades'  => $total,
            'win_rate'      => round($winRate, 2),
            'profit_factor' => round($profitFactor, 2),
            'profit_pct'    => round($profitPct, 2),
            'max_drawdown'  => round($maxDrawdown, 2),
            'final_equity'  => round($equity, 2),
        ],
    ]);

} catch (Throwable $e) {
    backtest_error(
        'Backtest failed: ' . $e->getMessage(),
        500,
        $e
    );
}
